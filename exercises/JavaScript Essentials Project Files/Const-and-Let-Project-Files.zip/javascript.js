
const name = "Kalob";

if(name == "Kalob") {
	// Do something
	var/let/const brothersName = "Nathan";
	console.log(brothersName);
} else {
	// Do something else
}

console.log(brothersName);


