(function() {
	console.log('You are awesome. Don\'t believe the negative thoughts.');
})();