// Example code:
// main = document.querySelector('#main');
// main.innerHMTL = 'New text';
// main.style.paddingLeft = '45px';