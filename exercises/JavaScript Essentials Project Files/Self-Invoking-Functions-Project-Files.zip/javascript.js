(function() {
	// Anything in here will automatically run when the function is done loading.

	var body = document.querySelector('body');

	body.style.backgroundColor = "#8c1515";
	body.style.color = "#fff";

	body.innerHTML = "Welcome to my page";

})();