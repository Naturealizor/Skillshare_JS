var x = function(num1, num2) {
	console.log(num1 + num2);
}

x(1, 2);
x(3, 4);
x(5, 6);
