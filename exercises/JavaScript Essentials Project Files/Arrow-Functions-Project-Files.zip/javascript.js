// Sample arrow pointer function with params
var add = (param1, param2) => {
	alert(param1 + param2);
}

add(13, 94);

// Regular function 
function name() {
	name = "John";
}

console.log(name)