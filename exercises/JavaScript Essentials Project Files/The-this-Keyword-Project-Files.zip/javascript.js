function anything() {

	if(this.number === undefined) {
		this.number = 0;
	}

	this.number++;

	console.log(this.number);
}


anything();
anything();
anything();
anything();
anything();
anything();
anything();
anything();
anything();
anything();
anything();
anything();