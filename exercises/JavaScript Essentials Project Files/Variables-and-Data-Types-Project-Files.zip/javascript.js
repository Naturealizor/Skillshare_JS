// __     __         _       _     _           
// \ \   / /_ _ _ __(_) __ _| |__ | | ___  ___ 
//  \ \ / / _` | '__| |/ _` | '_ \| |/ _ \/ __|
//   \ V / (_| | |  | | (_| | |_) | |  __/\__ \
//    \_/ \__,_|_|  |_|\__,_|_.__/|_|\___||___/
//                                             

// HOMEWORK:
// 1. Open your Inspector tool in your browser.
// 2. Create the following types of variables:
// 	a) String
// 	b) Integer
// 	c) Float
// 	d) Object
// 	e) Array

var name = ""; // Remember: strings user quotes. 
var age  = 55; // Integers don't need quotes, they are whole numbers.
var pi   = 3.14; // Floats are integers with decimals.
var obj  = {}; // Objects are basically variables inside variables.
var arr  = []; // Arrays are lists of variables.